﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C4_Bai3
{
    class FullTimeEmployee : Employee
    {
        public override float calculateSalary()
        {
            return 8 * getPaymentPerHour();
        }
    }
}
