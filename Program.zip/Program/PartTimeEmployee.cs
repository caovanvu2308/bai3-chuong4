﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C4_Bai3
{
    class PartTimeEmployee : Employee
    {
        // thuoc tinh
        private float workingHours;

        // phuong thuc khoi tao co tham so
        public PartTimeEmployee(string name, float paymentPerHour, float workingHours):base(name, paymentPerHour)
        {
            this.workingHours = workingHours;
        }

        public override float calculateSalary()
        {
            return workingHours * getPaymentPerHour();
        }
    }
}
