﻿using System;

namespace C4_Bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nhap 1 nhan vien lam PartTime va tinh tien cho nv do
            PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Nguyen Van An", 120000, 3.5f);
            float tienPhaiTra = partTimeEmployee.calculateSalary();
            Console.WriteLine("So tien phai tra cho nv la: " + tienPhaiTra);
        }
    }
}
