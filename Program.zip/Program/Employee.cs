﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C4_Bai3
{
    // lop truu tuong
    abstract class Employee : IEmployee
    {
        // thuoc tinh
        private string name;
        private float paymentPerHour;

        // phuong thuc
        //1. phuong thuc khoi tao khong tham so
        public Employee()
        {
            name = "";
            paymentPerHour = 0;
        }
        // 2. Phuong thuc khoi tao co tham so
        public Employee(string name, float paymentPerHour)
        {
            this.name = name;
            this.paymentPerHour = paymentPerHour;
        }

        // phuong thuc truu tuong de tinh luong nhan vien
        public abstract float calculateSalary();

        public string getName()
        {
            return name;
        }

        public float getPaymentPerHour()
        {
            return paymentPerHour;
        }
    }
}
